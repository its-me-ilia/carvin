$(function() {
	$('#nmvtisResultsBtn').click(function() {
		$('#nmvtisResultsBtn').text("View");
	});
});
